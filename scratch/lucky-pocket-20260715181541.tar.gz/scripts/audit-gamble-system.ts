import { db } from "../server/db.js";
import { calculateUserTotalEvaluatedAsset } from "../server/services/portfolioValuationService.js";
import { getEtfInterestMissingSummary } from "../server/services/etfInterestService.js";

const users = db.prepare("SELECT id, username FROM users ORDER BY id").all();
const valuations = users.map((user) => ({
  userId: user.id,
  username: user.username,
  ...calculateUserTotalEvaluatedAsset(db, user.id),
}));
const duplicateOwnerEtfs = db.prepare(`
  SELECT owner_user_id, COUNT(*) AS count, GROUP_CONCAT(id) AS stock_ids
  FROM stocks
  WHERE is_etf = 1 AND etf_tracking_type = 'owner_asset' AND status = 'acquired'
  GROUP BY owner_user_id HAVING COUNT(*) > 1
`).all();
const legacyTakeovers = db.prepare(`
  SELECT COUNT(*) AS count FROM hostile_takeover_events
  WHERE target_market_cap_snapshot IS NULL OR acquisition_cost_snapshot IS NULL
`).get().count;
const unsafeStocks = db.prepare(`
  SELECT COUNT(*) AS count FROM stocks
  WHERE status != 'delisted' AND is_etf = 0
    AND delist_risk_status = 'final_crash'
    AND delist_review_started_at IS NULL
`).get().count;
const report = {
  generatedAt: new Date().toISOString(),
  database: "sqlite",
  userCount: users.length,
  incompleteValuationCount: valuations.filter((row) => row.valuationComplete === false).length,
  incompleteValuations: valuations.filter((row) => row.valuationComplete === false).map((row) => ({
    userId: row.userId,
    username: row.username,
    errors: row.valuationErrors,
  })),
  duplicateOwnerEtfs,
  hostileTakeoversMissingMarketCapSnapshot: Number(legacyTakeovers || 0),
  finalCrashWithoutReviewCount: Number(unsafeStocks || 0),
  etfInterest: getEtfInterestMissingSummary(db),
  seasonRewardJobs: db.prepare(`
    SELECT id, season_number, status, error_message FROM season_reward_jobs ORDER BY id DESC LIMIT 20
  `).all(),
};

console.log(JSON.stringify(report, null, 2));
if (report.incompleteValuationCount > 0 || duplicateOwnerEtfs.length > 0 || Number(unsafeStocks) > 0) {
  process.exitCode = 2;
}

