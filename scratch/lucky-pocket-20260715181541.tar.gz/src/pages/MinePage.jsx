import { useEffect, useState, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api } from "../api/client";
import { useAuth } from "../context/AuthContext";
import { formatMoney } from "../utils/format";
import AnimatedMoney from "../components/AnimatedMoney";
import { PageContainer, SectionHeader, BaseCard, MoneyText } from "../components/ui";

export default function MinePage() {
  const { user, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [mining, setMining] = useState(false);
  const [floatingTexts, setFloatingTexts] = useState([]);
  const textIdRef = useRef(0);
  const rockRef = useRef(null);
  const lastClickTimeRef = useRef(0);

  useEffect(() => {
    let mounted = true;
    api("/mine/status")
      .then(data => {
        if (!mounted) return;
        if (!data.canEnterMine) {
          navigate("/home", { replace: true });
          return;
        }
        setStatus(data);
      })
      .catch(() => {
        if (mounted) navigate("/home");
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });
    return () => { mounted = false; };
  }, [navigate]);

  const addFloatingText = (text, type, x, y) => {
    const id = textIdRef.current++;
    setFloatingTexts(prev => [...prev, { id, text, type, x, y }]);
    setTimeout(() => {
      setFloatingTexts(prev => prev.filter(t => t.id !== id));
    }, 1000);
  };

  const handleMine = async (e) => {
    if (mining || !status || !status.canMine) return;

    const now = Date.now();
    if (now - lastClickTimeRef.current < 150) return; // Prevent absolute spam
    lastClickTimeRef.current = now;

    const rect = rockRef.current.getBoundingClientRect();
    // randomize click position slightly around the center
    const clickX = e.clientX || rect.left + rect.width / 2;
    const clickY = e.clientY || rect.top + rect.height / 2;

    setMining(true);
    rockRef.current.classList.remove("animate-rock-hit");
    void rockRef.current.offsetWidth; // trigger reflow
    rockRef.current.classList.add("animate-rock-hit");

    try {
      const res = await api("/mine/click", { method: "POST" });
      setStatus(prev => ({
        ...prev,
        balance: res.balanceAfter,
        canMine: res.canMine,
        totalMineClicks: prev.totalMineClicks + 1,
        totalMineEarned: prev.totalMineEarned + res.actualReward,
        recentFinds: [{
          resultType: res.resultType,
          label: res.label,
          reward: res.actualReward,
          createdAt: new Date().toISOString()
        }, ...prev.recentFinds].slice(0, 10)
      }));
      
      refreshUser();

      if (res.actualReward > 0) {
        addFloatingText(`+${res.actualReward}`, res.resultType, clickX, clickY);
      } else {
        addFloatingText("가득 찼어요!", "system", clickX, clickY);
      }
    } catch (err) {
      addFloatingText("앗!", "error", clickX, clickY);
    } finally {
      setTimeout(() => setMining(false), 80);
    }
  };

  if (loading) return <div className="page-content py-20 flex justify-center"><span className="loading loading-spinner text-primary" /></div>;
  if (!status) return null;

  return (
    <PageContainer>
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div>
          <SectionHeader title="탄광" eyebrow="COAL MINE" className="mb-2" />
          <p className="text-sm text-base-content/60 leading-relaxed">
            곡괭이를 들고 자원을 캐서 자산을 키워보세요.<br className="hidden sm:block" />
            가끔 금이나 다이아몬드가 나오면 더 큰 보상을 받을 수 있어요.
          </p>
        </div>
        <Link to="/home" className="btn btn-outline rounded-2xl min-h-12 w-full sm:w-auto font-bold px-6">나가기</Link>
      </div>

      <div className="grid gap-6 lg:grid-cols-[1fr_320px] mb-8">
        {/* Mining Area */}
        <BaseCard className="flex flex-col items-center justify-center p-8 min-h-[450px] relative overflow-hidden bg-gradient-to-b from-base-200 to-base-300 border-base-300">
          <div className="mb-auto w-full max-w-md bg-base-100 rounded-3xl p-5 shadow-sm border border-base-200 text-center">
            <span className="text-sm font-bold text-base-content/50 block mb-2">현재 자산</span>
            <div className="flex items-center justify-center gap-2">
              <strong className="text-3xl font-black text-primary tabular-nums tracking-tight">
                <AnimatedMoney value={status.balance} />
              </strong>
            </div>
          </div>

          <button 
            className="relative select-none outline-none group my-8"
            onClick={handleMine}
            disabled={!status.canMine}
            style={{ WebkitTapHighlightColor: 'transparent' }}
          >
            <div 
              ref={rockRef}
              className={`text-9xl transition-transform duration-75 drop-shadow-lg ${status.canMine ? 'cursor-pointer hover:scale-105 active:scale-95' : 'opacity-50 grayscale'}`}
              style={{ fontSize: "160px" }}
            >
              🪨
            </div>
            
            {status.canMine && (
              <div 
                className={`absolute -top-4 -right-12 text-7xl drop-shadow-md origin-bottom-right transition-transform duration-100 ${mining ? 'rotate-[-60deg]' : 'rotate-12 group-hover:rotate-0'}`}
                style={{ fontSize: "100px" }}
              >
                ⛏️
              </div>
            )}
          </button>
          
          <div className="mt-auto pt-8">
            {!status.canMine && (
              <span className="badge badge-error badge-outline font-bold p-4">오늘은 더 이상 캘 수 없어요!</span>
            )}
          </div>

          {/* Floating Texts */}
          {floatingTexts.map(t => (
            <div 
              key={t.id} 
              className={`fixed pointer-events-none z-50 text-2xl font-black animate-float-up drop-shadow-sm tracking-tight ${t.type === 'diamond' ? 'text-info' : t.type === 'gold' ? 'text-warning' : t.type === 'error' ? 'text-error' : 'text-primary'}`}
              style={{ left: t.x - 20, top: t.y - 20 }}
            >
              {t.text}
            </div>
          ))}
        </BaseCard>

        {/* Stats & History */}
        <div className="flex flex-col gap-5">
          <BaseCard>
            <h3 className="font-black text-base mb-4 flex items-center gap-2">
              <span className="text-xl">📊</span> 현황
            </h3>
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-base-200/60 rounded-2xl p-4 border border-base-200">
                <span className="block text-xs font-bold text-base-content/50 mb-1">총 캔 자원</span>
                <strong className="text-base font-black tabular-nums text-primary"><MoneyText value={status.totalMineEarned} compact /></strong>
              </div>
              <div className="bg-base-200/60 rounded-2xl p-4 border border-base-200">
                <span className="block text-xs font-bold text-base-content/50 mb-1">곡괭이질</span>
                <strong className="text-base font-black tabular-nums text-base-content/80">{status.totalMineClicks.toLocaleString()}회</strong>
              </div>
            </div>
          </BaseCard>

          <BaseCard className="flex-1 overflow-hidden flex flex-col min-h-[250px]">
            <h3 className="font-black text-base mb-4 flex items-center gap-2">
              <span className="text-xl">✨</span> 최근 발견
            </h3>
            <div className="flex-1 overflow-y-auto pr-2 space-y-2">
              {status.recentFinds.map((find, i) => (
                <div key={i} className="flex justify-between items-center bg-base-200/40 rounded-xl p-3 border border-base-200">
                  <span className="flex items-center gap-2">
                    <span className="text-lg">{find.resultType === 'diamond' ? '💎' : find.resultType === 'gold' ? '🟡' : find.resultType === 'iron' ? '⚪' : find.resultType === 'coal' ? '⚫' : '🪨'}</span>
                    <span className="font-bold text-sm text-base-content/80">{find.label}</span>
                  </span>
                  <span className="font-black tabular-nums text-primary">+{formatMoney(find.reward)}</span>
                </div>
              ))}
              {status.recentFinds.length === 0 && (
                <div className="flex flex-col items-center justify-center h-full py-8 text-center gap-2">
                  <span className="text-4xl opacity-20">🪨</span>
                  <span className="text-sm font-bold text-base-content/40">아직 발견한 광물이 없어요.</span>
                </div>
              )}
            </div>
          </BaseCard>
        </div>
      </div>
    </PageContainer>
  );
}
